package tech.hyperone.trackex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
